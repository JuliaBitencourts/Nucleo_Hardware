
let produtos = [];

let lista = document.getElementById("lista-produtos");

for (let produto of produtos) {
    let card = document.createElement("div");
    card.className = "card";

    let nome = document.createElement("h3");
    nome.textContent = produto.nome;

    let descricao = document.createElement("p");
    descricao.textContent = produto.descricao;

    let preco = document.createElement("p");
    preco.textContent = "Preço: " + produto.preco;

    let botao = document.createElement("button");
    botao.textContent = "Adicionar";

    botao.addEventListener("click", function() {
    let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

        carrinho.push(produto);

        localStorage.setItem("carrinho", JSON.stringify(carrinho));
        alert("Produto adicionado ao carrinho!");
    });

    card.appendChild(nome);
    card.appendChild(descricao);
    card.appendChild(preco);
    card.appendChild(botao);
    lista.appendChild(card);
}
